import elem_graficos
class background:
    background = []
    def __init__(self,size,color):
        self.color = color
        self.size = size
        self.background = elem_graficos.grille(self.size,self.color)

    def print(self):
        self.background.draw()
    def resetar(self):
        self.background.screen.fill([0,0,0])
