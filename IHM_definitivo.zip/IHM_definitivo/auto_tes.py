class auto_tes:
	def __init__(self,ref_min,ref_max,num_sal,step):
		self.ref_min    = ref_min;
		self.ref_max    = ref_max;
		self.num_sal    = num_sal;
		self.step       = step;
		self.count      = 0;
		self.flag_ref   = 0;
		self.flag_ciclo = 0;
		self.ref        = self.ref_min;
	def iteracao(self):
		if self.count > self.step:
			self.count = 0;
		if self.count == 0:
			self.ref = self.ref_min + self.flag_ref*(self.ref_max-self.ref_min)/self.num_sal;
			if self.flag_ciclo == 0:
				self.flag_ref = self.flag_ref+1;
			if self.ref >= self.ref_max:
				self.flag_ciclo = 1;
			if self.flag_ciclo == 1:
				self.flag_ref = self.flag_ref-1;
			if self.ref <= self.ref_min:
				self.flag_ciclo = 0;
		self.count = self.count+1;
	def get_ref(self):
		return self.ref;
		
	def iteracao_de(self):
		if self.count > self.step:
			self.count = 0;
		if self.count == 0:
			self.ref = self.ref_max - self.flag_ref*(self.ref_max-self.ref_min)/self.num_sal;
			self.flag_ref = self.flag_ref+1;
			if self.ref <= self.ref_min:
				self.ref = 0;
		self.count = self.count+1;
			