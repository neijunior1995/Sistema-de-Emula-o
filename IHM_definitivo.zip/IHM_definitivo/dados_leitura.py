import serial;


class comunicacao:
    def __init__(self,baudrate,porta,caminho):
        self.ser = serial.Serial();
        self.ser.baudrate = baudrate;
        self.ser.port = porta;
        self.caminho = caminho;
        self.ser.open();
        self.dados = open(self.caminho,'a')
    def ler_serial(self):
        self.VALUE_SERIAL=self.ser.readline();
        self.SVALUE_SERIAL=self.VALUE_SERIAL.decode('utf-8');
        self.SVALUE_SERIAL = self.SVALUE_SERIAL.rstrip('\n');
        self.SVALUE_SERIAL = self.SVALUE_SERIAL.rstrip('\r');
    def escrever_arquivo(self,texto):
        self.texto = texto;
        self.dados.write(self.texto);
    def finalizar_com(self):
        self.ser.close();
        self.dados.close();
