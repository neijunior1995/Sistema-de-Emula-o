import serial;


class comunicacao:
    def __init__(self,baudrate,porta,caminho):
        self.ser = serial.Serial();
        self.ser.baudrate = baudrate;
        self.ser.port = porta;
        self.caminho = caminho;
        self.ser.open();
        self.dados = open(self.caminho,'a')
    def ler_serial(self):
        self.SVALUE_SERIAL=self.ser.readline();
        self.SVALUE_SERIAL=str(self.SVALUE_SERIAL);
        self.SVALUE_SERIAL = self.SVALUE_SERIAL.rstrip("\\r\\n'");
#        self.SVALUE_SERIAL = self.SVALUE_SERIAL.rstrip('\\r');
        self.SVALUE_SERIAL = self.SVALUE_SERIAL[2:len(self.SVALUE_SERIAL)-1]+'\n'
    def escrever_arquivo(self,texto):
        self.texto = texto;
        self.dados.write(self.texto);
    def finalizar_com(self):
        self.ser.close();
        self.dados.close();
