import dados_leitura,time,serial,pygame,background,sys,graphic,botton,seg_8,elem_graficos
import _thread as thread


# Comunicação
baudrate = 250000;
porta = 'COM10';
caminho = 'database.txt';
ti = time.time()
comu = dados_leitura.comunicacao(baudrate,porta,caminho)

# Elemntos graficos IHM
count_B = 1;
sizeback = 1600,900 # Tamanho da tela
colorback = 192,192,192 # Cor do fundo
background = background.background(sizeback,colorback) # definindo o primeiro fundo
divi_freq = 200; # Divisor de frequência para não gastar processamento em excesso com os gráficos
flag_divi_freq = 1; # flag utilizada para dividir a frequência
# Configuracao do grafico
sizegraphic = 615,430 
colorgraphic = 0,0,195
positiongraphic = 70,70
sizegraphic2 = 330,300
positiongraphic2 = 75,565
colorgraphi2 = 255,255,255
point_max = 2000;
string_key = '';
ESTADO = ''; # Variável que armazena o estado do emulador
#--------------------------------frame de velocidade-------------------------------------------
graphic1 = graphic.graphic(background.background,sizegraphic,colorgraphic,colorgraphi2,positiongraphic)#Desenho dos gráficos
graphic2 = graphic.graphic(background.background,sizegraphic2,colorgraphic,colorgraphi2,positiongraphic2)
_7_seg = seg_8.display_7seg() # Botoes de 7 segmentos
botton1 = botton.botton_4circle(background.background,[700,215],[255,0,0],[0,0,255],20)
surf_inf = pygame.Surface([1600,360]) # Sufarce inferior
surf_sup = pygame.Surface([1600,560]) # Sufarce superior
botton2 = botton.botton_4circle(background.background,[430,570],[255,0,0],[0,0,255],20)
botton2.size = [160,220]
botton2.colorf = [150,150,150]
texCapAI = elem_graficos.text_box(surf_inf,30,[0,0,0])
texCapCI = 'Capacitor C'
indAguarPart = elem_graficos.circle(surf_sup,[1200,160],20,[0,0,0])
indPart = elem_graficos.circle(surf_sup,[1200,300],20,[0,0,0])
indRegVer = elem_graficos.circle(surf_sup,[1200,440],20,[0,0,0])
texSuper = elem_graficos.text_box(surf_sup,30,[0,0,0])
#Indicador das lâmpadas
indcarga = elem_graficos.circle(surf_inf,[750,10],10,[0,0,0])
n_cargas = 0;
#Indicador de sincronismo
indsin = elem_graficos.circle(surf_inf,[750,10],10,[0,0,0])
sin_flag = 0;
#Botoes de acionamento do sistema de emulacao
Bcarga_on  = botton.rectangle_botton(background.background,[20,10],[255,255,0],[750,65+560])
Bcarga_off = botton.rectangle_botton(background.background,[20,10],[0,0,255],[750,65+560])
Bligar     = botton.rectangle_botton(background.background,[20,10],[0,0,255],[750,65+560])
FCligar    = botton.rectangle_botton(background.background,[20,10],[0,0,255],[850,65+560])
IGligar    = botton.rectangle_botton(background.background,[20,10],[0,0,255],[1100,65+560])
ECligar    = botton.rectangle_botton(background.background,[20,10],[0,0,255],[750,120+560])
EAligar    = botton.rectangle_botton(background.background,[20,10],[0,0,255],[1100,120+560])
#Indicadores de acionamento do sistema de emulacao
indB = elem_graficos.circle(surf_inf,[750,10],10,[0,0,0])
indFC = elem_graficos.circle(surf_inf,[850,10],10,[0,0,0])
indIG= elem_graficos.circle(surf_inf,[1100,10],10,[0,0,0])
indEC = elem_graficos.circle(surf_inf,[750,85],10,[0,0,0])
indEA= elem_graficos.circle(surf_inf,[1100,85],10,[0,0,0])
#Funcoes e variáveis relacionadas com a tensão----------------------------------------------------
botton4 = botton.botton_4circle(background.background,[700,215],[255,0,0],[0,0,255],20)
botton4.size = [160,220]
botton4.name = ['Tensão','Corrente','Potência elétrica','Sinal de controle']
#Funcoes e variáveis relacionadas com o PSS
botton5 = botton.botton_4circle(background.background,[700,215],[255,0,0],[0,0,255],20)
botton5.size = [160,220]
botton5.name = ['Tensão','Frequência','Desvio de potência','ESP']
# Funções relacionadas a IHM
botton3 = botton.botton_4circle(background.background,[1400,150],[255,0,0],[0,0,255],20)
botton3.size = [160,220]
botton3.colorf = [192,192,192]
botton3.name = ['RV','RAT','ESP','Desligar']
Bgravar = botton.rectangle_botton(background.background,[175,100],[0,0,0],[1250,800])
Bstop = botton.rectangle_botton(background.background,[175,100],[255,50,50],[1250+175,800])
texGravar = elem_graficos.text_box(Bgravar.surface,30,[255,255,255])
texStop = elem_graficos.text_box(Bstop.surface,30,[255,255,255])


x1  = [];
x2  = [];
x3  = [];
x4  = [];
x5  = [];
x6  = [];
x7  = [];
x8  = [];
x9  = [];
x10 = [];
x11 = [];
x12 = [];
x13 = [];
x14 = [];
x15 = [];
x16 = [];
x17 = [];
x18 = [];
x19 = [];
x20 = [];
x21 = [];
x22 = [];
x23 = [];
xg1 = [0,0.001];
xg2 = [0,0.001];
yg1 = [0,0.001];
yg2 = [0,0.001];


colorLine = [0,0,0];
#--------------------Variaveis do sistema para regulação de velocidade-------------------------------------------
I_arm_mcc   = [];# corrente de armadura do motor de corrente continua
I_cam_mcc   = [];# Corente de campo do motor de corrente continua
V_arm_mcc   = [];# Tensão do capacitor de armadura do motor de corrente continua
V_cam_mcc   = [];# tensão do capacitor de campo do motor de corrente continua
dut_arm_mcc = [];# dut de armadura do motor de corrente continua
dut_cam_mcc = [];# dut de campo do motor de corrente continua
Vel_tub     = [];# velocidade da turbina hidráulica
SER_PO      = [];# Posição do servoposicionador
RV_SC       = [];# Esforço de controle do regulador de velocidade
V_ter       = [];# Tensão do terminal da máquina
u_rat       = [];# Sinal de controle do regulador de tensão
V_sg        = [];# Tensão do capacitor que alimenta a excitação do gerador sincrono
Vt_ref      = [];# Referência do regulador de tensão
P_e         = [];# Potência elétrica da máquina
V_bus       = [];# Tensão do barramento
dP_e        = [];# Variação de potência elétrica
PSS_c       = [];# Sinal de controle do PSS_c
Pm          = [];# Potência mecanica da turbina elétrica
I_arsg      = [];# Corrente elétrica
I_casg      = [];# corrente elétrica do campo do gerador sincgrono
Vb_fase     = [];# Fase da tensão do barramento
W_tub       = [];# Fase da tensão do barramento
F_bus       = [];# Frequência do barramento
#teclado
def teclado():
    if event.key == pygame.K_a:
        tec = 'A'
    elif event.key == pygame.K_b:
        tec = 'B'
    elif event.key == pygame.K_c:
        tec = 'C'
    elif event.key == pygame.K_d:
        tec = 'D'
    elif event.key == pygame.K_e:
        tec = 'E'
    elif event.key == pygame.K_f:
        tec = 'F'
    elif event.key == pygame.K_g:
        tec = 'G'
    elif event.key == pygame.K_h:
        tec = 'H'
    elif event.key == pygame.K_i:
        tec = 'I'
    elif event.key == pygame.K_j:
        tec = 'J'
    elif event.key == pygame.K_k:
        tec = 'K'
    elif event.key == pygame.K_l:
        tec = 'L'
    elif event.key == pygame.K_m:
        tec = 'M'
    elif event.key == pygame.K_n:
        tec = 'N'
    elif event.key == pygame.K_o:
        tec = 'O'
    elif event.key == pygame.K_p:
        tec = 'P'
    elif event.key == pygame.K_q:
        tec = 'Q'
    elif event.key == pygame.K_r:
        tec = 'R'
    elif event.key == pygame.K_s:
        tec = 'S'
    elif event.key == pygame.K_t:
        tec = 'T'
    elif event.key == pygame.K_u:
        tec = 'U'
    elif event.key == pygame.K_v:
        tec = 'V'
    elif event.key == pygame.K_w:
        tec = 'W'
    elif event.key == pygame.K_x:
        tec = 'X'
    elif event.key == pygame.K_y:
        tec = 'Y'
    elif event.key == pygame.K_z:
        tec = 'Z'
    elif event.key == pygame.K_BACKSPACE:
        tec = '\b'
    elif event.key == pygame.K_KP_ENTER or event.key == 13:
        tec = '\n'
    elif event.key == pygame.K_KP0:
        tec = '0'
    elif event.key == pygame.K_KP1:
        tec = '1'
    elif event.key == pygame.K_KP2:
        tec = '2'
    elif event.key == pygame.K_KP3:
        tec = '3'
    elif event.key == pygame.K_KP4:
        tec = '4'
    elif event.key == pygame.K_KP5:
        tec = '5'
    elif event.key == pygame.K_KP6:
        tec = '6'
    elif event.key == pygame.K_KP7:
        tec = '7'
    elif event.key == pygame.K_KP8:
        tec = '8'
    elif event.key == pygame.K_KP9:
        tec = '9'
    else:
        tec ='';
    return tec;

def IHM_elementosRV(x1,y1,x2,y2,colorLine):
    graphic1.rec1.surface.fill(colorgraphic) # desenho do grafico superior
    graphic1.rec2.surface.fill(colorgraphi2) # desenho do frafico superior
    graphic2.rec1.surface.fill(colorgraphic)
    graphic2.rec2.surface.fill(colorgraphi2)
    surf_sup.fill(colorback)
    strflag = '';
    for i in string_key:
        strflag = strflag+i;
    texSuper.write_text(strflag)
    texSuper.print([1400,400])
    texSuper.write_text(ESTADO)
    texSuper.print([1400,450])
    texSuper.write_text('Aguarda Partida')
    texSuper.print([1120,120])
    if ESTADO == 'RE1Z' or ESTADO == 'RE1AZ' or ESTADO == 'RE2Z' or ESTADO == 'RE3Z' or ESTADO == 'RE4Z' or ESTADO == 'RE4AZ':
	    indAguarPart.cor = [0,255,0];
    else:
	    indAguarPart.cor = [0,0,0];
    indAguarPart.desenhar_circulo()
    texSuper.write_text('Partindo')
    if ESTADO == 'RV1Z' or ESTADO == 'RV2Z':
	    indPart.cor = [0,255,0];
    else:
	    indPart.cor = [0,0,0];
    if (ESTADO == 'RV3Z' or ESTADO[0:2] == 'RT'or ESTADO[0:2] == 'RS')and ESTADO != 'RD1Z':
	    indRegVer.cor = [0,255,0];
    else:
	    indRegVer.cor = [0,0,0];
    texSuper.print([1160,260])
    indPart.desenhar_circulo()
    texSuper.write_text('RV')
    texSuper.print([1185,400])
    indRegVer.desenhar_circulo()
    background.print();# Limpando o fundo
    background.background.screen.blit(surf_sup,[0,0])
    surf_sup.fill([192,192,192])#colorback
    texCapAI.write_text('Ligar')
    texCapAI.print([750,35])
    texCapAI.write_text('Iniciar Cap.')
    texCapAI.print([850,35])
    texCapAI.write_text('Finalizar Cap.')
    texCapAI.print([1100,35])
    texCapAI.write_text('Alimentar Buck')
    texCapAI.print([750,100])
    texCapAI.write_text('Iniciar Par. Hidra.')
    texCapAI.print([1000,100])
#Indicadores de acionamento do sistema de emulacao
    if ESTADO == 'RD1Z':
       indB.cor = [0,255,00]
    else:
       indB.cor = [0,0,0]
    indB.position =[750,10];
    indB.desenhar_circulo()
    if ESTADO == 'RE1AZ':
       indFC.cor = [0,255,00]
    else:
       indFC.cor = [0,0,0]
    if ESTADO == 'RE2Z':
       indIG.cor = [0,255,00]
    else:
       indIG.cor = [0,0,0]
    if ESTADO == 'RE3Z':
       indEC.cor = [0,255,00]
    else:
       indEC.cor = [0,0,0]
    if ESTADO == 'RE4AZ':
       indEA.cor = [0,255,00]
    else:
       indEA.cor = [0,0,0]
    indFC.position = [850,10];
    indFC.desenhar_circulo()
    indIG.position = [1100,10];
    indIG.desenhar_circulo()
    indEC.position = [750,85];
    indEC.desenhar_circulo()
    indEA.position = [1100,85];
    indEA.desenhar_circulo()
    
    texCapAI.write_text('Campo')
    texCapAI.print([750,200])
    if len(V_cam_mcc) > 1:
        texCapAI.write_text(str(V_cam_mcc[len(V_cam_mcc)-1])+' '+'V')
    texCapAI.print([750,230])
    texCapAI.write_text('Armadura')
    texCapAI.print([1000,200])
    if len(V_arm_mcc) > 1:
        texCapAI.write_text(str(V_arm_mcc[len(V_arm_mcc)-1])+' '+'V')
    texCapAI.print([1000,230])
    background.background.screen.blit(surf_inf,[0,560])
    surf_inf.fill([150,150,150])
    if len(x2) > 2:
        graphic2.grafic_line(x2,y2,[0,0,255])
        graphic2.print()
    botton1.desenhar_4botton()
    botton1.print()
    if len(x1) > 2:
        graphic1.grafic_line(x1,y1,colorLine)
        graphic1.print()
    botton2.name = ['Dut A','Corrente A','Dut B','Corrente B']
    botton2.desenhar_4botton()
    botton2.print()
    botton3.desenhar_4botton()
    botton3.print()
    Bligar.position = [750,65+560]
    Bligar.imprimir_botton()
    FCligar.position = [850,65+560]
    FCligar.imprimir_botton()
    IGligar.position = [1100,65+560]
    IGligar.imprimir_botton()
    ECligar.position = [750,120+560]
    ECligar.imprimir_botton()
    EAligar.position = [1100,120+560]
    EAligar.imprimir_botton()
    texGravar.write_text('Gravar')
    texGravar.print([50,50])
    Bgravar.imprimir_botton()
    texStop.write_text('STOP')
    texStop.print([50,50])
    Bstop.imprimir_botton()
    if len(Vel_tub) > 2:
        _7_seg.print(background.background.screen,[750,75],(W_tub[len(W_tub)-1]*1818/1000)) # Desenho do dispay de 7 segmentos
    else:
        _7_seg.print(background.background.screen,[750,75],0) # Desenho do dispay de 7 segmentos
    pygame.display.flip();#Desenhando dos objetos
#---------------------------frame de tensao---------------------------------------------------------
def IHM_elementosRAT(x1,y1,x2,y2,colorLine):
    graphic1.rec1.surface.fill(colorgraphic) # desenho do grafico superior
    graphic1.rec2.surface.fill(colorgraphi2) # desenho do frafico superior
    graphic2.rec1.surface.fill(colorgraphic)
    graphic2.rec2.surface.fill(colorgraphi2)
    surf_sup.fill(colorback)
    strflag = '';
    for i in string_key:
        strflag = strflag+i;
    texSuper.write_text(ESTADO)
    texSuper.print([1400,450])
    if ESTADO[0:2] == 'RE' or ESTADO[0:2] == 'RV':
        indAguarPart.cor = [0,255,0]
    else:
        indAguarPart.cor = [0,0,0]
    if ESTADO[0:2] == 'RT' and ESTADO != 'RT4Z':
        indPart.cor = [0,255,0];
    else:
        indPart.cor = [0,0,0];
    if (ESTADO == 'RT4Z' or ESTADO[0:2] == 'RS') and ESTADO != 'RD1Z':
        indRegVer.cor = [0,255,0]
    else:
        indRegVer.cor = [0,0,0]
    texSuper.write_text(strflag)
    texSuper.print([1400,400])
    texSuper.write_text('Aguarda Partida')
    texSuper.print([1120,120])
    indAguarPart.desenhar_circulo()
    texSuper.write_text('Partindo')
    texSuper.print([1160,260])
    indPart.desenhar_circulo()
    texSuper.write_text('RAT')
    texSuper.print([1185,400])
    texSuper.write_text('Frequência')
    texSuper.print([900,200])
    texSuper.write_text('Tensão')
    texSuper.print([800,50])
    indRegVer.desenhar_circulo()
    background.print();# Limpando o fundo
    background.background.screen.blit(surf_sup,[0,0])
    surf_sup.fill([192,192,192])#colorback
    texCapAI.write_text('Ener. Cam.')
    texCapAI.print([750,35])
    texCapAI.write_text('Ener. Trafo.')
    texCapAI.print([900,35])
    texCapAI.write_text('Con. Trafo.')
    texCapAI.print([750,100])
    texCapAI.write_text('Iniciar RAT')
    texCapAI.print([900,100])
#Indicadores de acionamento do sistema de emulacao
    if ESTADO == 'RV3Z':
       indB.cor = [0,255,0];
    else:
       indB.cor = [0,0,0];
    indB.position = [750,10];
    indB.desenhar_circulo()
    if ESTADO == 'RT1AZ':
       indFC.cor = [0,255,0];
    else:
       indFC.cor = [0,0,0];
    indFC.position = [950,10];
    indFC.desenhar_circulo()
    if ESTADO == 'RT2Z':
       indIG.cor = [0,255,0];
    else:
       indIG.cor = [0,0,0];
    indIG.position=[750,85]
    indIG.desenhar_circulo()
    if ESTADO == 'RT3Z':
       indEC.cor = [0,255,0];
    else:
       indEC.cor = [0,0,0];
    indEC.position=[950,85]
    indEC.desenhar_circulo()
    
    texCapAI.write_text('Tensão')
    texCapAI.print([750,200])
    if len(V_ter) > 1:
        texCapAI.write_text(str(V_ter[len(V_ter)-1])+'V')
        texCapAI.print([750,230])
    texCapAI.write_text('Corrente')
    texCapAI.print([1000,200])
    if len(I_arsg) > 1:
        texCapAI.write_text(str(I_arsg[len(I_arsg)-1])+'A')
        texCapAI.print([1000,230])
    background.background.screen.blit(surf_inf,[0,560])
    surf_inf.fill([150,150,150])
    if len(x2) > 1:
        graphic2.grafic_line(x2,y2,[0,0,255])
    graphic2.print()
    botton4.size = [400,220]
    botton4.desenhar_4botton()
    botton4.print()
    if len(x1) > 1:
        graphic1.grafic_line(x1,y1,colorLine)
    graphic1.print()
    botton2.size = [300,220]
    botton2.name = ['T-Excitaçãa','T-Capacitor ESG','Frequência','Corrente ESG']
    botton2.desenhar_4botton()
    botton2.print()
    botton3.desenhar_4botton()
    botton3.print()
    i1 = 0;
    for i in range(5):
        i1 = i1+1;
        if n_cargas >= i1:
            indcarga.cor = [255,255,0];
        else:
            indcarga.cor = [0,0,255];
        indcarga.position=[1260+i*80,85]
        indcarga.desenhar_circulo()
    for i in range(5):
        i1 = i1+1;
        if n_cargas >= i1:
            indcarga.cor = [255,255,0];
        else:
            indcarga.cor = [0,0,255];
        indcarga.position=[1260+i*80,130]
        indcarga.desenhar_circulo()
    Bcarga_on.position=[1330,760];
    Bcarga_on.imprimir_botton();
    Bcarga_off.position=[1500,760];
    Bcarga_off.imprimir_botton();
    Bcarga_on.imprimir_botton();
    Bligar.position=[750,65+560];
    Bligar.imprimir_botton()
    FCligar.position=[900,65+560];
    FCligar.imprimir_botton()
    IGligar.position=[750,120+560];
    IGligar.imprimir_botton()
    ECligar.position=[900,120+560];
    ECligar.imprimir_botton()
    texGravar.write_text('Gravar')
    texGravar.print([50,50])
    Bgravar.imprimir_botton()
    texStop.write_text('STOP')
    texStop.print([50,50])
    Bstop.imprimir_botton()
    if len(V_ter) > 1:
        _7_seg.print(background.background.screen,[750,75],int(V_ter[len(V_ter)-1])) # Desenho do dispay de 7 segmentos
    else:
        _7_seg.print(background.background.screen,[750,75],0) # Desenho do dispay de 7 segmentos
    pygame.display.flip();#Desenhando dos objetos

#---------------------------Estabilzador de Sistemas Elétricos de Potência---------------------------------------------------------
def IHM_elementosPSS(xg1,yg1,xg2,yg2,colorLine):
    graphic1.rec1.surface.fill(colorgraphic) # desenho do grafico superior
    graphic1.rec2.surface.fill(colorgraphi2) # desenho do frafico superior
    graphic2.rec1.surface.fill(colorgraphic)
    graphic2.rec2.surface.fill(colorgraphi2)
    surf_sup.fill(colorback)
    strflag = '';
    for i in string_key:
        strflag = strflag+i;
    if ESTADO == 'RS1AZ' or ESTADO == 'RS2Z' or  ESTADO == 'RS3Z':
        indAguarPart.cor = [0,255,0];
    else:
        indAguarPart.cor = [0,0,0];
    if ESTADO == 'RS2Z' or  ESTADO == 'RS3Z':
        indPart.cor = [0,255,0];
    else:
        indPart.cor = [0,0,0];
    if  ESTADO == 'RS3Z':
        indRegVer.cor = [0,255,0];
    else:
        indRegVer.cor = [0,0,0];
	#indicador do sincronismo-----
    if sin_flag == 2:
        indsin.cor = [0,255,0];
    else:
        indsin.cor = [0,0,0];
    indsin.position=[1500,30];
    indsin.desenhar_circulo();
    if sin_flag == 1:
        indsin.cor = [0,255,0];
    else:
        indsin.cor = [0,0,0];
    indsin.position=[1420,30];
    indsin.desenhar_circulo();
    if sin_flag == 0:
        indsin.cor = [0,255,0];
    else:
        indsin.cor = [0,0,0];
    indsin.position=[1360,30];
    indsin.desenhar_circulo();
    texSuper.write_text(ESTADO)
    texSuper.print([1400,450])
    texSuper.write_text(strflag)
    texSuper.print([1400,400])
    texSuper.write_text('Sincronizado')
    texSuper.print([1120,120])
    indAguarPart.desenhar_circulo()
    texSuper.write_text('Conectado')
    texSuper.print([1160,260])
    indPart.desenhar_circulo()
    texSuper.write_text('PSS')
    texSuper.print([1185,400])
    texSuper.write_text('Frequência')
    texSuper.print([900,200])
    texSuper.write_text('Potência Elétrica')
    texSuper.print([800,50])
    indRegVer.desenhar_circulo()
    background.print();# Limpando o fundo
    background.background.screen.blit(surf_sup,[0,0])
    surf_sup.fill([192,192,192])#colorback
    texCapAI.write_text('Sincro Módulo')
    texCapAI.print([750,35])
    texCapAI.write_text('Desconectar a Rede')
    texCapAI.print([1000,35])
    texCapAI.write_text('Conectar a Rede')
    texCapAI.print([750,100])
    texCapAI.write_text('Iniciar PSS')
    texCapAI.print([1000,100])
#Indicadores de acionamento do sistema de emulacao
    if ESTADO == 'RT4Z':
       indB.cor =[0,255,0];
    else:
       indB.cor =[0,0,0];

    indB.position = [750,10];
    indB.desenhar_circulo()
    if ESTADO == 'RS1AZ':
       indIG.cor =[0,255,0];
    else:
       indIG.cor =[0,0,0];
    indIG.position=[750,85]
    indIG.desenhar_circulo()
    if ESTADO == 'RS2Z':
       indEC.cor =[0,255,0];
    else:
       indEC.cor =[0,0,0];
    indEC.position=[1050,85]
    indEC.desenhar_circulo()
    if ESTADO == 'RS3Z' or ESTADO == 'RS2Z':
       indFC.cor =[0,255,0];
    else:
       indFC.cor =[0,0,0];
    i1 = 0;
    for i in range(5):
        i1 = i1+1;
        if n_cargas >= i1:
            indcarga.cor = [255,255,0];
        else:
            indcarga.cor = [0,0,255];
        indcarga.position=[1260+i*80,85]
        indcarga.desenhar_circulo()
    for i in range(5):
        i1 = i1+1;
        if n_cargas >= i1:
            indcarga.cor = [255,255,0];
        else:
            indcarga.cor = [0,0,255];
        indcarga.position=[1260+i*80,130]
        indcarga.desenhar_circulo()
    indFC.position = [1050,10];
    indFC.desenhar_circulo()
    texCapAI.write_text('Tensão')
    texCapAI.print([750,200])
    texCapAI.write_text('312'+' '+'V')
    texCapAI.print([750,230])
    texCapAI.write_text('Corrente')
    texCapAI.print([1000,200])
    texCapAI.write_text('312'+' '+'V')
    texCapAI.print([1000,230])
    background.background.screen.blit(surf_inf,[0,560])
    surf_inf.fill([150,150,150])
    Bcarga_on.position=[1330,750];
    Bcarga_on.imprimir_botton();
    Bcarga_off.position=[1500,750];
    Bcarga_off.imprimir_botton();
    Bcarga_on.imprimir_botton();
    if len(xg2) > 0:
        graphic2.grafic_line(xg2,yg2,[0,0,255])
    graphic2.print()
    botton5.size = [300,220]
    botton5.desenhar_4botton()
    botton5.print()
    if len(xg1) > 0:
        graphic1.grafic_line(xg1,yg1,colorLine)
    graphic1.print()
    botton2.size = [300,220]
    botton2.name = ['Tensão Bar','Frequência Bar','Fase Bar','Corrente GS']
    botton2.desenhar_4botton()
    botton2.print()
    botton3.size = [600,220]
    botton3.desenhar_4botton()
    botton3.print()
    Bligar.position=[750,65+560];
    Bligar.imprimir_botton()
    FCligar.position=[1050,65+560];
    FCligar.imprimir_botton()
    IGligar.position=[750,120+560];
    IGligar.imprimir_botton()
    ECligar.position=[1050,120+560];
    ECligar.imprimir_botton()
    texGravar.write_text('Gravar')
    texGravar.print([50,50])
    Bgravar.imprimir_botton()
    texStop.write_text('STOP')
    texStop.print([50,50])
    Bstop.imprimir_botton()
    _7_seg.print(background.background.screen,[750,75],100) # Desenho do dispay de 7 segmentos
    pygame.display.flip();#Desenhando dos objetos

for i in range(100):
    comu.ser.readline();
DISPLAYSURF = pygame.display.set_mode((0,0), pygame.FULLSCREEN)
while 1:
    for event in pygame.event.get():
       time.sleep(0.0005);
       if event.type == pygame.QUIT:
           sys.exit()
       elif event.type == pygame.MOUSEBUTTONDOWN:
           botton2.get_mouse_position();
           botton3.get_mouse_position();
           Bligar.get_mouse_position();
           FCligar.get_mouse_position();
           IGligar.get_mouse_position();
           ECligar.get_mouse_position();
           EAligar.get_mouse_position();
           Bstop.get_mouse_position();
           Bcarga_on.get_mouse_position();
           Bcarga_off.get_mouse_position();
           if botton3.flag2 == 1:
               botton1.get_mouse_position();
               if Bligar.state == 1:
                  comu.ser.write(b"RLMZ\n")
                  Bligar.state =0;
               if FCligar.state == 1:
                  comu.ser.write(b"RFMZ\n")
                  FCligar.state =0;
               if IGligar.state == 1:
                  comu.ser.write(b"REBZ\n")
                  IGligar.state =0;
               if ECligar.state == 1:
                  comu.ser.write(b"REMZ\n")
                  ECligar.state =0;
               if EAligar.state == 1:
                  comu.ser.write(b"RIHZ\n")
                  EAligar.state =0;
           if botton3.flag2 == 2:
               botton4.get_mouse_position();
               if Bligar.state == 1:
                  comu.ser.write(b"RLEZ\n")
                  Bligar.state =0;
               if FCligar.state == 1:
                  comu.ser.write(b"RFEZ\n")
                  FCligar.state =0;
               if IGligar.state == 1:
                  comu.ser.write(b"REEZ\n")
                  IGligar.state =0;
               if ECligar.state == 1:
                  comu.ser.write(b"RIGZ\n")
                  ECligar.state =0;
               if Bcarga_on.state == 1:
                  comu.ser.write(b"RCG1Z\n")
                  Bcarga_on.state = 0;
               if Bcarga_off.state == 1:
                  comu.ser.write(b"RCG0Z\n")
                  Bcarga_off.state = 0;
           if botton3.flag2 == 3:
               botton5.get_mouse_position();
               if Bligar.state == 1:
                  comu.ser.write(b"RSMZ\n")
                  Bligar.state =0;
               if FCligar.state == 1:
                  comu.ser.write(b"RDSZ\n")
                  FCligar.state =0;
               if IGligar.state == 1:
                  comu.ser.write(b"RCBZ\n")
                  IGligar.state =0;
               if ECligar.state == 1:
                  comu.ser.write(b"RIPZ\n")
                  ECligar.state =0;
               if Bcarga_on.state == 1:
                  comu.ser.write(b"RCG1Z\n")
                  Bcarga_on.state = 0;
               if Bcarga_off.state == 1:
                  comu.ser.write(b"RCG0Z\n")
                  Bcarga_off.state = 0;
           if botton3.flag2 == 4:
               comu.ser.write(b"RDMZ\n")
               botton3.flag2 = 1
           if Bstop.state == 1:
               sys.exit()
           Bligar.state =0;
           FCligar.state =0;
           IGligar.state =0;
           ECligar.state =0;
           EAligar.state =0;		   
           Bgravar.get_mouse_position();
           if Bgravar.state == 0:
               Bgravar.color = [0,0,0];
           else:
               Bgravar.color = [0,255,0];
       elif event.type == pygame.KEYDOWN:
           att = teclado()
           if att == '\b' and len(string_key)>0:
               string_key=string_key[:-1];
           elif att == '\n':
               bytes1= bytes(string_key, 'utf-8')
               comu.ser.write(bytes1)
               string_key = '';
           else:
               string_key = string_key+att;
                
            
                
    if comu.ser.inWaiting() > 4:
        comu.ler_serial();
        ta = time.time() - ti;
        Sflag = "{0:.20f}".format(ta);
        if len(comu.SVALUE_SERIAL) > 1:
            if Bgravar.state ==  1:
                Wflag = Sflag+'\t'+comu.SVALUE_SERIAL[0]+'\t'+comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]+'\n';
                comu.escrever_arquivo(Wflag);
            if comu.SVALUE_SERIAL[0] == 'A':
                I_arm_mcc.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x1.append(ta)
                if len(x1) > point_max:
                    del x1[0];
                    del I_arm_mcc[0];
            if comu.SVALUE_SERIAL[0] == 'B':
                I_cam_mcc.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x2.append(ta)
                if len(x2) > point_max:
                    del x2[0];
                    del I_cam_mcc[0];
            if comu.SVALUE_SERIAL[0] == 'C':
                V_arm_mcc.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x3.append(ta)
                if len(x3) > point_max:
                    del x3[0];
                    del V_arm_mcc[0];
            if comu.SVALUE_SERIAL[0] == 'D':
                V_cam_mcc.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x4.append(ta)
                if len(x4) > point_max:
                    del x4[0];
                    del V_cam_mcc[0];
            if comu.SVALUE_SERIAL[0] == 'E':
                dut_arm_mcc.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x5.append(ta)
                if len(x5) > point_max:
                    del x5[0];
                    del dut_arm_mcc[0];
            if comu.SVALUE_SERIAL[0] == 'F':
                dut_cam_mcc.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x6.append(ta)
                if len(x6) > point_max:
                    del x6[0];
                    del dut_cam_mcc[0];
            if comu.SVALUE_SERIAL[0] == 'G':
                Vel_tub.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x7.append(ta)
                if len(x7) > point_max:
                    del x7[0];
                    del Vel_tub[0];
            if comu.SVALUE_SERIAL[0] == 'H':
                SER_PO.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x8.append(ta)
                if len(x8) > point_max:
                    del x8[0];
                    del SER_PO[0];
            if comu.SVALUE_SERIAL[0] == 'I':
                RV_SC.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x9.append(ta)
                if len(x9) > point_max:
                    del x9[0];
                    del RV_SC[0];
            if comu.SVALUE_SERIAL[0] == 'J':
                V_ter.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x10.append(ta)
                if len(x10) > point_max:
                    del x10[0];
                    del V_ter[0];
            if comu.SVALUE_SERIAL[0] == 'K':
                u_rat.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x11.append(ta)
                if len(x11) > point_max:
                    del x11[0];
                    del u_rat[0];
            if comu.SVALUE_SERIAL[0] == 'L':
                V_sg.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x12.append(ta)
                if len(x12) > point_max:
                    del x12[0];
                    del V_sg[0];
            if comu.SVALUE_SERIAL[0] == 'M':
                Vt_ref.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x13.append(ta)
                if len(x13) > point_max:
                    del x13[0];
                    del Vt_ref[0];
            if comu.SVALUE_SERIAL[0] == 'N':
                P_e.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x14.append(ta)
                if len(x14) > point_max:
                    del x14[0];
                    del P_e[0];
            if comu.SVALUE_SERIAL[0] == 'O':
                V_bus.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x15.append(ta)
                if len(x15) > point_max:
                    del x15[0];
                    del V_bus[0];
            if comu.SVALUE_SERIAL[0] == 'P':
                dP_e.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x16.append(ta)
                if len(x16) > point_max:
                    del x16[0];
                    del dP_e[0];
            if comu.SVALUE_SERIAL[0] == 'R':
                PSS_c.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x17.append(ta)
                if len(x17) > point_max:
                    del x17[0];
                    del PSS_c[0];
            if comu.SVALUE_SERIAL[0] == 'S':
                Pm.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x18.append(ta)
                if len(x18) > point_max:
                    del x18[0];
                    del Pm[0];
            if comu.SVALUE_SERIAL[0] == 'T':
                I_arsg.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x19.append(ta)
                if len(x19) > point_max:
                    del x19[0];
                    del I_arsg[0];
            if comu.SVALUE_SERIAL[0] == 'U':
                I_casg.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x20.append(ta)
                if len(x20) > point_max:
                    del x20[0];
                    del I_casg[0];
            if comu.SVALUE_SERIAL[0] == 'V':
                Vb_fase.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x21.append(ta)
                if len(x21) > point_max:
                    del x21[0];
                    del Vb_fase[0];
            if comu.SVALUE_SERIAL[0] == 'W':
                F_bus.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x22.append(ta)
                if len(x22) > point_max:
                    del x22[0];
                    del F_bus[0];
            if comu.SVALUE_SERIAL[0] == 'X':
                W_tub.append(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                print(float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]))
                x23.append(ta)
                if len(x23) > point_max:
                    del x23[0];
                    del W_tub[0];
            if comu.SVALUE_SERIAL[0] == 'Z':
                ESTADO = 'R'+comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]+"Z";
            if comu.SVALUE_SERIAL[0] == 'a':
                n_cargas = float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]);
            if comu.SVALUE_SERIAL[0] == 'b':
                sin_flag = float(comu.SVALUE_SERIAL[1:len(comu.SVALUE_SERIAL)]);
            if botton3.flag2 == 1:
                if botton1.flag2 == 1:
                    xg1 = x23;
                    yg1 = W_tub;
                elif botton1.flag2 == 2:
                    xg1 = x18;
                    yg1 = Pm;
                elif botton1.flag2 == 3:
                    xg1 = x9;
                    yg1 = RV_SC;
                elif botton1.flag2 == 4:
                    xg1 = x8;
                    yg1 = SER_PO ;
                
                if botton2.flag2 == 1:
                    xg2 = x5;
                    yg2 = dut_arm_mcc;
                elif botton2.flag2 == 2:
                    xg2 = x1;
                    yg2 = I_arm_mcc;
                elif botton2.flag2 == 3:
                    xg2 = x6;
                    yg2 = dut_cam_mcc;
                elif botton2.flag2 == 4:
                    xg2 = x2;
                    yg2 = I_cam_mcc;
					
            if botton3.flag2 == 2:
                if botton4.flag2 == 1:
                    xg1 = x10;
                    yg1 = V_ter;
                elif botton4.flag2 == 2:
                    xg1 = x19;
                    yg1 = I_arsg;
                elif botton4.flag2 == 3:
                    xg1 = x14;
                    yg1 = P_e;
                elif botton4.flag2 == 4:
                    xg1 = x11;
                    yg1 = u_rat;
                
                if botton2.flag2 == 1:
                    xg2 = x2;
                    yg2 = I_arm_mcc;
                elif botton2.flag2 == 2:
                    xg2 = x12;
                    yg2 = V_sg;
                elif botton2.flag2 == 3:
                    xg2 = x7;
                    yg2 = Vel_tub;
                elif botton2.flag2 == 4:
                    xg2 = x20;
                    yg2 = I_casg;
            if botton3.flag2 == 3:
                if botton4.flag2 == 1:
                    xg1 = x10;
                    yg1 = V_ter;
                elif botton4.flag2 == 2:
                    xg1 = x23;
                    yg1 = W_tub;
                elif botton4.flag2 == 3:
                    xg1 = x16;
                    yg1 = dP_e;
                elif botton4.flag2 == 4:
                    xg1 = x17;
                    yg1 = PSS_c;
                
                if botton2.flag2 == 1:
                    xg1 = x15;
                    yg1 = V_bus;
                elif botton4.flag2 == 2:
                    xg1 = x22;
                    yg1 = F_bus;
                elif botton4.flag2 == 3:
                    xg1 = x21;
                    yg1 = Vb_fase;
                elif botton4.flag2 == 4:
                    xg1 = x20;
                    yg1 = I_arsg;
        flag_divi_freq+=1;
        if flag_divi_freq > divi_freq:
            if botton3.flag2 == 1:
                thread.start_new_thread(IHM_elementosRV,(xg1,yg1,xg2,yg2,colorLine,))
            if botton3.flag2 == 2:
                thread.start_new_thread(IHM_elementosRAT,(xg1,yg1,xg2,yg2,colorLine,))
            if botton3.flag2 == 3:
                thread.start_new_thread(IHM_elementosPSS,(xg1,yg1,xg2,yg2,colorLine,))
            if botton3.flag2 == 4:
                thread.start_new_thread(IHM_elementosRV,(xg1,yg1,xg2,yg2,colorLine,))
            flag_divi_freq = 1;
comu.finalizar_com();
