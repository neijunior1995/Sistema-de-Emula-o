import pygame
def teclado1():
    if event.key == pygame.K_a:
        tec = 'a'
    elif event.key == pygame.K_b:
        tec = 'b'
    elif event.key == pygame.K_c:
        tec = 'c'
    elif event.key == pygame.K_d:
        tec = 'd'
    elif event.key == pygame.K_e:
        tec = 'e'
    elif event.key == pygame.K_f:
        tec = 'f'
    elif event.key == pygame.K_g:
        tec = 'g'
    elif event.key == pygame.K_h:
        tec = 'h'
    elif event.key == pygame.K_i:
        tec = 'i'
    elif event.key == pygame.K_j:
        tec = 'j'
    elif event.key == pygame.K_k:
        tec = 'k'
    elif event.key == pygame.K_l:
        tec = 'l'
    elif event.key == pygame.K_m:
        tec = 'm'
    elif event.key == pygame.K_n:
        tec = 'n'
    elif event.key == pygame.K_o:
        tec = 'o'
    elif event.key == pygame.K_p:
        tec = 'p'
    elif event.key == pygame.K_q:
        tec = 'q'
    elif event.key == pygame.K_r:
        tec = 'r'
    elif event.key == pygame.K_s:
        tec = 's'
    elif event.key == pygame.K_t:
        tec = 't'
    elif event.key == pygame.K_u:
        tec = 'u'
    elif event.key == pygame.K_v:
        tec = 'v'
    elif event.key == pygame.K_w:
        tec = 'w'
    elif event.key == pygame.K_x:
        tec = 'x'
    elif event.key == pygame.K_y:
        tec = 'y'
    elif event.key == pygame.K_z:
        tec = 'z'
    elif event.key == pygame.K_BACKSPACE:
        tec = '\b'
    elif event.key == pygame.K_KP_ENTER:
        tec = '\n'
    elif event.key == pygame.K_KP0:
        tec = '0'
    elif event.key == pygame.K_KP1:
        tec = '1'
    elif event.key == pygame.K_KP2:
        tec = '2'
    elif event.key == pygame.K_KP3:
        tec = '3'
    elif event.key == pygame.K_KP4:
        tec = '4'
    elif event.key == pygame.K_KP5:
        tec = '5'
    elif event.key == pygame.K_KP6:
        tec = '6'
    elif event.key == pygame.K_KP7:
        tec = '7'
    elif event.key == pygame.K_KP8:
        tec = '8'
    elif event.key == pygame.K_KP9:
        tec = '9'
    return tec;
