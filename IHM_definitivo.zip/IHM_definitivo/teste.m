clear all;close all;clc
a = readtable('database.txt');
b = a{:,1};
k = length(b);

for i = 1:1:(k-1)
t(i) = b(i+1,1)-b(i,1);
end
t_total = 0;
for i = t
t_total = t_total+  i;
end
t = t_total/length(t);

time = b-b(1);
grandeza = a{:,2};
valores = a{:,3};
c1 = 1;c2 = 1;
for i = 1:length(time)
if grandeza{i} == 'A'
    y(c1,2) = valores(i);
    y(c1,1) = time(i);
    c1 = c1+1;
end
if grandeza{i} == 'B'
    u(c2,2) = valores(i);
    u(c2,1) = time(i);
    c2 = c2+1;
end
end

plot(((y(:,1))),y(:,2))
%hold on
%s = tf('s');

%G = 1/(s^2+s+2);

%step(G)
