import elem_graficos,pygame,math

class graphic:
    #graphic = []
    def __init__(self,grille,size,color1,color2,position):
        self.DH = 10;
        self.DV = 10;
        self.space = 50
        self.width = 1
        self.grille = grille
        self.size   = size
        self.size2   = [self.size[0]-self.space,self.size[1]-self.space]
        self.color1  = color1
        self.color2  = color2
        self.colorv  = [123,50,20]
        self.position = position
        self.position2 = [self.position[0]+self.space/2,self.position[1]+self.space/2]
        self.rec1 = elem_graficos.rectangle(self.grille,self.size,self.color1,self.position)
        self.rec2 = elem_graficos.rectangle(self.grille,self.size2,self.color2,self.position2)
        self.memgra = []
        self.surface = pygame.Surface(self.size2)
        self.surface.set_colorkey()
        self.caixa_texto = elem_graficos.text_box(self.rec1.surface,15,[0,0,0])
          
    def print(self):
        pygame.draw.line(self.rec2.surface,self.colorv,[0,0],[0,self.size2[1]],self.width)
        for count in range(1,self.DH):
            pygame.draw.line(self.rec2.surface,self.colorv,[count*self.size2[0]/(self.DH-1),0],[count*self.size2[0]/(self.DH-1),self.size2[1]],self.width)
        pygame.draw.line(self.rec2.surface,self.colorv,[0,0],[self.size2[0],0],self.width)
        for count in range(1,self.DV):
            pygame.draw.line(self.rec2.surface,self.colorv,[0,count*self.size2[1]/(self.DV-1)],[self.size2[0],count*self.size2[1]/(self.DV-1)],self.width)  
        self.rec1.draw()
        self.rec2.draw()
    def extremos(self,x,y):
        self.x = x;
        self.y = y;
        self.flagmax = self.x[0]
        self.flagmin = self.x[0]
        if len(self.x) > 1:
            for count in range(1,len(x)):
                if self.x[count] > self.flagmax: self.flagmax = self.x[count]
                if self.x[count] < self.flagmin : self.flagmin = self.x[count]
        self.extrx = [self.flagmax,self.flagmin]
        self.flagmax = self.y[0]
        self.flagmin = self.y[0]
        if len(self.y) > 1:
            for count in range(1,len(y)):
                if self.y[count] > self.flagmax: self.flagmax = self.y[count]
                if self.y[count] < self.flagmin : self.flagmin = self.y[count]
        self.extry = [self.flagmax+0.5,self.flagmin-0.5]
    def grafic_line(self,x,y,colorline):
        self.x = x
        self.y = y
        self.colorline = colorline

        self.pointV = len(x);

        if self.extry[0] == self.extry[0]:
            self.extry[0] = self.extry[0]+0.1;
            self.extry[1] = self.extry[1]-0.1;
        if self.pointV > 1:
            for countV in range(1,self.pointV):
                self.x0 = (self.x[countV-1]-self.extrx[1])/(self.extrx[0]-self.extrx[1])
                self.x1 = (self.x[countV]-self.extrx[1])/(self.extrx[0]-self.extrx[1])
                self.y0 = (self.y[countV-1]-self.extry[1])/(self.extry[0]-self.extry[1])
                self.y1 = (self.y[countV]-self.extry[1])/(self.extry[0]-self.extry[1])
                
                pygame.draw.line(self.rec2.surface,self.colorline,[self.x0*self.size2[0],self.size2[1]-self.y0*self.size2[1]],[self.x1*self.size2[0],self.size2[1]-self.y1*self.size2[1]],1)

        self.caixa_texto.write_text("{0:.2f}".format(self.extrx[1]))
        self.flagH1 = self.size[1]-self.caixa_texto.size
        self.caixa_texto.print([self.space/2,self.flagH1])
        for count in range(1,self.DH):
            self.flagH2 = count*self.size2[0]/(self.DH-1)
            self.flagprint = (self.extrx[0]-self.extrx[1])*count/(self.DH-1)+self.extrx[1]
            self.caixa_texto.write_text("{0:.2f}".format(self.flagprint))
            self.caixa_texto.print([self.space/2+self.flagH2,self.flagH1])
        self.caixa_texto.write_text("{0:.2f}".format(self.extry[1]))
        self.flagH1 = self.size[1]-self.space/2
        self.caixa_texto.print([0,self.flagH1])
        for count in range(1,self.DV):
            self.flagH2 = self.size[1] - count*self.size2[1]/(self.DV-1)
            self.flagprint = (self.extry[0]-self.extry[1])*(self.DV-count)/(self.DV-1)+self.extry[1]
            self.caixa_texto.write_text("{0:.2f}".format(self.flagprint))
            self.caixa_texto.print([0,self.size[1]-self.flagH2])
