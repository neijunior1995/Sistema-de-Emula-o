import pygame

class display_7seg:
    def __init__(self):
        self.size = [70,90] # tamanho dos segmentos
        self.desloc = 70 # deslocamento dos segmentos
        self.number_0 =  pygame.image.load('number\\num_0.png')
        self.number_0 = pygame.transform.scale(self.number_0, self.size)
        self.number_1 =  pygame.image.load('number\\num_1.png')
        self.number_1 = pygame.transform.scale(self.number_1, self.size)
        self.number_2 =  pygame.image.load('number\\num_2.png')
        self.number_2 = pygame.transform.scale(self.number_2, self.size)
        self.number_3 =  pygame.image.load('number\\num_3.png')
        self.number_3 = pygame.transform.scale(self.number_3, self.size)
        self.number_4 =  pygame.image.load('number\\num_4.png')
        self.number_4 = pygame.transform.scale(self.number_4, self.size)
        self.number_5 =  pygame.image.load('number\\num_5.png')
        self.number_5 = pygame.transform.scale(self.number_5, self.size)
        self.number_6 =  pygame.image.load('number\\num_6.png')
        self.number_6 = pygame.transform.scale(self.number_6, self.size)
        self.number_7 =  pygame.image.load('number\\num_7.png')
        self.number_7 = pygame.transform.scale(self.number_7, self.size)
        self.number_8 =  pygame.image.load('number\\num_8.png')
        self.number_8 = pygame.transform.scale(self.number_8, self.size)
        self.number_9 =  pygame.image.load('number\\num_9.png')
        self.number_9 = pygame.transform.scale(self.number_9, self.size)
    def print(self,grille,position,number):
        self.grille = grille;
        self.position = position;
        self.number = number;
        self.numString = "{0:.0f}".format(self.number)
        if self.number < 10:
            self.dis1 = self.number_0
            self.dis2 = self.number_0
            self.dis3 = self.number_0
            if self.numString[0] == '0':
                self.dis4 = self.number_0;
            elif self.numString[0] == '1':
                self.dis4 = self.number_1;
            elif self.numString[0] == '2':
                self.dis4 = self.number_2;
            elif self.numString[0] == '3':
                self.dis4 = self.number_3;
            elif self.numString[0] == '4':
                self.dis4 = self.number_4;
            elif self.numString[0] == '5':
                self.dis4 = self.number_5;
            elif self.numString[0] == '6':
                self.dis4 = self.number_6;
            elif self.numString[0] == '7':
                self.dis4 = self.number_7;
            elif self.numString[0] == '8':
                self.dis4 = self.number_8;
            elif self.numString[0] == '9':
                self.dis4 = self.number_9;
        elif self.number < 100:
            self.dis1 = self.number_0
            self.dis2 = self.number_0
            if self.numString[1] == '0':
                self.dis4 = self.number_0;
            elif self.numString[1] == '1':
                self.dis4 = self.number_1;
            elif self.numString[1] == '2':
                self.dis4 = self.number_2;
            elif self.numString[1] == '3':
                self.dis4 = self.number_3;
            elif self.numString[1] == '4':
                self.dis4 = self.number_4;
            elif self.numString[1] == '5':
                self.dis4 = self.number_5;
            elif self.numString[1] == '6':
                self.dis4 = self.number_6;
            elif self.numString[1] == '7':
                self.dis4 = self.number_7;
            elif self.numString[1] == '8':
                self.dis4 = self.number_8;
            elif self.numString[1] == '9':
                self.dis4 = self.number_9;

            if self.numString[0] == '0':
                self.dis3 = self.number_0;
            elif self.numString[0] == '1':
                self.dis3 = self.number_1;
            elif self.numString[0] == '2':
                self.dis3 = self.number_2;
            elif self.numString[0] == '3':
                self.dis3 = self.number_3;
            elif self.numString[0] == '4':
                self.dis3 = self.number_4;
            elif self.numString[0] == '5':
                self.dis3 = self.number_5;
            elif self.numString[0] == '6':
                self.dis3 = self.number_6;
            elif self.numString[0] == '7':
                self.dis3 = self.number_7;
            elif self.numString[0] == '8':
                self.dis3 = self.number_8;
            elif self.numString[0] == '9':
                self.dis3 = self.number_9;
        elif self.number < 1000:
            self.dis1 = self.number_0
            if self.numString[2] == '0':
                self.dis4 = self.number_0;
            elif self.numString[2] == '1':
                self.dis4 = self.number_1;
            elif self.numString[2] == '2':
                self.dis4 = self.number_2;
            elif self.numString[2] == '3':
                self.dis4 = self.number_3;
            elif self.numString[2] == '4':
                self.dis4 = self.number_4;
            elif self.numString[2] == '5':
                self.dis4 = self.number_5;
            elif self.numString[2] == '6':
                self.dis4 = self.number_6;
            elif self.numString[2] == '7':
                self.dis4 = self.number_7;
            elif self.numString[2] == '8':
                self.dis4 = self.number_8;
            elif self.numString[2] == '9':
                self.dis4 = self.number_9;

            if self.numString[1] == '0':
                self.dis3 = self.number_0;
            elif self.numString[1] == '1':
                self.dis3 = self.number_1;
            elif self.numString[1] == '2':
                self.dis3 = self.number_2;
            elif self.numString[1] == '3':
                self.dis3 = self.number_3;
            elif self.numString[1] == '4':
                self.dis3 = self.number_4;
            elif self.numString[1] == '5':
                self.dis3 = self.number_5;
            elif self.numString[1] == '6':
                self.dis3 = self.number_6;
            elif self.numString[1] == '7':
                self.dis3 = self.number_7;
            elif self.numString[1] == '8':
                self.dis3 = self.number_8;
            elif self.numString[1] == '9':
                self.dis3 = self.number_9;

            if self.numString[0] == '0':
                self.dis2 = self.number_0;
            elif self.numString[0] == '1':
                self.dis2 = self.number_1;
            elif self.numString[0] == '2':
                self.dis2 = self.number_2;
            elif self.numString[0] == '3':
                self.dis2 = self.number_3;
            elif self.numString[0] == '4':
                self.dis2 = self.number_4;
            elif self.numString[0] == '5':
                self.dis2 = self.number_5;
            elif self.numString[0] == '6':
                self.dis2 = self.number_6;
            elif self.numString[0] == '7':
                self.dis2 = self.number_7;
            elif self.numString[0] == '8':
                self.dis2 = self.number_8;
            elif self.numString[0] == '9':
                self.dis2 = self.number_9;
        else:
            if self.numString[3] == '0':
                self.dis4 = self.number_0;
            elif self.numString[3] == '1':
                self.dis4 = self.number_1;
            elif self.numString[3] == '2':
                self.dis4 = self.number_2;
            elif self.numString[3] == '3':
                self.dis4 = self.number_3;
            elif self.numString[3] == '4':
                self.dis4 = self.number_4;
            elif self.numString[3] == '5':
                self.dis4 = self.number_5;
            elif self.numString[3] == '6':
                self.dis4 = self.number_6;
            elif self.numString[3] == '7':
                self.dis4 = self.number_7;
            elif self.numString[3] == '8':
                self.dis4 = self.number_8;
            elif self.numString[3] == '9':
                self.dis4 = self.number_9;

            if self.numString[2] == '0':
                self.dis3 = self.number_0;
            elif self.numString[2] == '1':
                self.dis3 = self.number_1;
            elif self.numString[2] == '2':
                self.dis3 = self.number_2;
            elif self.numString[2] == '3':
                self.dis3 = self.number_3;
            elif self.numString[2] == '4':
                self.dis3 = self.number_4;
            elif self.numString[2] == '5':
                self.dis3 = self.number_5;
            elif self.numString[2] == '6':
                self.dis3 = self.number_6;
            elif self.numString[2] == '7':
                self.dis3 = self.number_7;
            elif self.numString[2] == '8':
                self.dis3 = self.number_8;
            elif self.numString[2] == '9':
                self.dis3 = self.number_9;

            if self.numString[1] == '0':
                self.dis2 = self.number_0;
            elif self.numString[1] == '1':
                self.dis2 = self.number_1;
            elif self.numString[1] == '2':
                self.dis2 = self.number_2;
            elif self.numString[1] == '3':
                self.dis2 = self.number_3;
            elif self.numString[1] == '4':
                self.dis2 = self.number_4;
            elif self.numString[1] == '5':
                self.dis2 = self.number_5;
            elif self.numString[1] == '6':
                self.dis2 = self.number_6;
            elif self.numString[1] == '7':
                self.dis2 = self.number_7;
            elif self.numString[1] == '8':
                self.dis2 = self.number_8;
            elif self.numString[1] == '9':
                self.dis2 = self.number_9;

            if self.numString[0] == '0':
                self.dis1 = self.number_0;
            elif self.numString[0] == '1':
                self.dis1 = self.number_1;
            elif self.numString[0] == '2':
                self.dis1 = self.number_2;
            elif self.numString[0] == '3':
                self.dis1 = self.number_3;
            elif self.numString[0] == '4':
                self.dis1 = self.number_4;
            elif self.numString[0] == '5':
                self.dis1 = self.number_5;
            elif self.numString[0] == '6':
                self.dis1 = self.number_6;
            elif self.numString[0] == '7':
                self.dis1 = self.number_7;
            elif self.numString[0] == '8':
                self.dis1 = self.number_8;
            elif self.numString[0] == '9':
                self.dis1 = self.number_9;
        
        self.grille.blit(self.dis1,self.position)
        self.grille.blit(self.dis2,[self.position[0]+self.desloc,self.position[1]])
        self.grille.blit(self.dis3,[self.position[0]+2*self.desloc,self.position[1]])
        self.grille.blit(self.dis4,[self.position[0]+3*self.desloc,self.position[1]])
        
