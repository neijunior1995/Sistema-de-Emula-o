import pygame,sys
class elem_graficos:
    def __init__(self,size,color):
        self.size = size
        self.color = color

class grille(elem_graficos):
    screen = []
    def __init__(self,size,color):
        elem_graficos.__init__(self,size,color)
        self.screen = pygame.display.set_mode(size)
    def draw(self):
        self.screen.fill(self.color)

class rectangle(elem_graficos):
    position =[]
    grade   =[]
    def __init__(self,grade,size,color,position):
        self.grade = grade
        elem_graficos.__init__(self,size,color)
        self.position = position
        self.screen = self.grade.screen
        self.surface = pygame.Surface(self.size)
        rectan = pygame.Rect(0,0,self.size[0],self.size[1])
        pygame.draw.rect(self.surface,color,rectan)
    def draw(self):
        self.screen.blit(self.surface,self.position)


class text_box(elem_graficos):
    def __init__(self,surface,size,color):
        self.surface = surface
        self.size = size
        self.color = color
        pygame.font.init()          
    def write_text(self,text):
        self.font_default  = pygame.font.get_default_font()
        self.text_in = pygame.font.SysFont(self.font_default,self.size)
        self.text = text
        self.texto_font = self.text_in.render(self.text,1,self.color)
    def print(self,position):
        self.position = position
        self.surface.blit(self.texto_font,self.position)
class circle:
    def __init__(self,suface,position,radio,cor):
        self.surface = suface;
        self.position = position;
        self.radio = radio;
        self.cor =cor;
    def desenhar_circulo(self):
        pygame.draw.circle(self.surface,self.cor,self.position,self.radio)
