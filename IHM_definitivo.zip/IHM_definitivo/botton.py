import pygame,elem_graficos
class botton_circle():        
    def __init__(self,grille,position,colorb,colorsur,radio):
        self.position = position
        self.grille = grille
        self.colorb = colorb
        self.colorsur = colorsur
        self.radio = radio
        self.flag2 = 1
    def desenhar_circlo(self):
        self.surface = pygame.Surface([self.radio*2,self.radio*2])
        self.surface.set_colorkey(0)
        self.botton = pygame.draw.circle(self.surface,self.colorb,[self.radio,self.radio],self.radio)
    def print(self):
        self.grille.screen.blit(self.surface,[self.position[0],self.position[1]])
    def get_mouse_position(self):
        self.mou_position = pygame.mouse.get_pos();
        self.pressed = 1;
    def pressed(self):
        for event in pygame.event.get():            
                self.pressed2 = 2
class botton_4circle(botton_circle):
    def __init__(self,grille,position,colorb,colorsur,radio):
        self.position = position
        self.grille = grille
        self.colorb = colorb
        self.colorsur = colorsur
        self.radio = radio
        botton_circle.__init__(self,self.grille,self.position,self.colorb,self.colorsur,self.radio)
        self.name    = ['Velocidade','Potência','Sinal de controle','Servoposionador']
        self.size = [425,220]#Tamanho do superfície do quatros botoes
        self.colorf = [192,192,192]
    def desenhar_4botton(self):
        self.surface = pygame.Surface(self.size)
        #self.surface.set_colorkey(0)
        self.surface.fill(self.colorf)
        self.nameBox = elem_graficos.text_box(self.surface,28,[0,0,0])#Configuração da legenda dos botões
        #self.color = self.colorb
        for i in range(1,5):
            if self.pressed == 1:
                flag = (self.position[0]+35-self.mou_position[0])**2+(self.position[1]+35+(i-1)*50-self.mou_position[1])**2
                if flag < self.radio**2:
                    self.flag2 = i
        self.pressed = 0
        for i in range(1,5):
            if self.flag2 == i:
                self.color = self.colorsur
            else:
                self.color = self.colorb            
            self.botton = pygame.draw.circle(self.surface,self.color,[35,35+(i-1)*50],self.radio)#posição dos botões
            self.nameBox.write_text(self.name[i-1])#Escrevendo o texto desejado
            self.nameBox.print([35+20,35-10+(i-1)*50])#imprimindo no local desejado
            #print([self.position[0]+35,35+(i-1)*50+self.position[1]])
class rectangle_botton:
    def __init__(self,grade,size,color,position):
        self.state = 0;
        self.grade = grade;
        self.screen = self.grade.screen;
        self.size = size;
        self.color = color;
        self.position = position;
        self.surface = pygame.Surface(self.size);
        self.rectan = pygame.Rect(0,0,self.size[0],self.size[1]);
    def imprimir_botton(self):
        self.screen.blit(self.surface,self.position);
        pygame.draw.rect(self.surface,self.color,self.rectan);
    def get_mouse_position(self):
        self.mou_position = pygame.mouse.get_pos();
        if self.mou_position[0] > self.position[0] and self.mou_position[0] < self.position[0]+self.size[0]:
            if self.mou_position[1] > self.position[1] and self.mou_position[1] < self.position[1]+self.size[1]:
                if self.state == 1:
                    self.state =0;
                else:
                    self.state = 1;
#Exemplo event mouse

#event polling:
##self.keys is [] 256 len. 
#self.mouse = ((0,0), 0, 0, 0, 0, 0, 0) #(pos, b1,b2,b3,b4,b5,b6)
##squeezing a new Apple mouse is button 6. 
#for event in pygame.event.get():
#	if event.type == pygame.QUIT:
#		self.running = 0
#	elif event.type == pygame.MOUSEBUTTONDOWN:
#		self.mouse[event.button] = 1
#		self.mouse[0] = event.pos
#	elif event.type == pygame.MOUSEBUTTONUP:
#		self.mouse[event.button] = 0
#		self.mouse[0] = event.pos
#	elif event.type == pygame.MOUSEMOTION:
#		self.mouse[0] = event.pos
#	elif event.type == pygame.KEYDOWN:
#		self.keys[event.key % 255] = 1
#	elif event.type == pygame.KEYUP:
#		self.keys[event.key % 255] = 0
